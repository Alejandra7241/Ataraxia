function myFunction() {
    document.getElementById("cargando").style.display = "block";
}
;

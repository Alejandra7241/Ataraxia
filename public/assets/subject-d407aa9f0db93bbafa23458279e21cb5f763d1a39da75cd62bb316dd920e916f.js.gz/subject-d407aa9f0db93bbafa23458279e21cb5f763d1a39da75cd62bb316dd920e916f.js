function editASubject(code){
    
    alert(code);
}
;
